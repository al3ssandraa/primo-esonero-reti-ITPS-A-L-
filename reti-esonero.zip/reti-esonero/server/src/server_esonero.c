/*
 ============================================================================
 Name        : server_esonero.c
 Author      : Alessandra Loiodice (802371)
 Version     :
 Copyright   : Your copyright notice
 Description : server
 ============================================================================
 */



#include "protocol.h"

// Generates a numeric password
void generate_numeric(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Restrict password length
   for (int i = 0; i < length; i++) {
       password[i] = '0' + rand() % 10; // Fill with random digits
   }
   password[length] = '\0'; // End with a null terminator
}

// Generates an alphabetic password
void generate_alpha(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Restrict password length
   for (int i = 0; i < length; i++) {
       password[i] = 'a' + rand() % 26; // Fill with random lowercase letters
   }
   password[length] = '\0'; // End with a null terminator
}

// Generates a mixed password (digits and letters)
void generate_mixed(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Restrict password length
   for (int i = 0; i < length; i++) {
       int type = rand() % 2; // Randomly choose between digit or letter
       password[i] = (type == 0) ? ('0' + rand() % 10) : ('a' + rand() % 26); // Assign character
   }
   password[length] = '\0'; // End with a null terminator
}

// Generates a secure password with special characters
void generate_secure(char *password, int length) {
   if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Restrict password length
   const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()"; // Available characters
   int charset_size = sizeof(charset) - 1; // Total characters in the set
   for (int i = 0; i < length; i++) {
       password[i] = charset[rand() % charset_size]; // Randomly pick a character
   }
   password[length] = '\0'; // End with a null terminator
}

int main(void) {
   #if defined WIN32
   WSADATA wsa_data;
   int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
   if (result != 0) {
       printf("Error at WSAStartup\n");
       return -1;
   }
   #endif

   printf("Using port %d for communication...\n", PROTOPORT);

   int server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (server_socket < 0) {
       perror("Socket creation failed");
       clearwinsock();
       return -1;
   }

   struct sockaddr_in sad;
   memset(&sad, 0, sizeof(sad));
   sad.sin_family = AF_INET;
   sad.sin_addr.s_addr = INADDR_ANY;
   sad.sin_port = htons(PROTOPORT);

   if (bind(server_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
       perror("Binding failed");
       closesocket(server_socket);
       clearwinsock();
       return -1;
   }

   if (listen(server_socket, 5) < 0) {
       perror("Listen failed");
       closesocket(server_socket);
       clearwinsock();
       return -1;
   }

   printf("Server is running and waiting for connections...\n");
   srand((unsigned) time(NULL));

   while (1) {
       struct sockaddr_in cad;
       int client_socket;
       int client_len = sizeof(cad);

       client_socket = accept(server_socket, (struct sockaddr *)&cad, &client_len);
       if (client_socket < 0) {
           perror("Accept failed");
           closesocket(server_socket);
           clearwinsock();
           return -1;
       }

       printf("New connection from %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));
       char buffer[BUFFERSIZE];
       int bytes_received;

       while ((bytes_received = recv(client_socket, buffer, BUFFERSIZE - 1, 0)) > 0) {
           buffer[bytes_received] = '\0'; // Terminate received string
           printf("Received: '%s'\n", buffer); // Log received data

           buffer[strcspn(buffer, "\n")] = 0; // Remove newline character

           if (strcmp(buffer, "q") == 0) { // Check for quit command
               printf("Client requested to close the connection.\n");
               break;
           }

           char type;
           int length;
           if (sscanf(buffer, "%c %d", &type, &length) != 2) { // Parse type and length
               send(client_socket, "Invalid input format. Use: <type> <length>\n", 44, 0);
               continue;
           }

           if (length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) { // Validate length
               const char *error_msg = "Invalid password length. Must be between 6 and 32.\n";
               send(client_socket, error_msg, strlen(error_msg), 0);
               continue;
           }

           char password[MAX_PASSWORD_LENGTH + 1];

           switch (type) { // Generate password based on type
               case 'n':
                   generate_numeric(password, length);
                   break;
               case 'a':
                   generate_alpha(password, length);
                   break;
               case 'm':
                   generate_mixed(password, length);
                   break;
               case 's':
                   generate_secure(password, length);
                   break;
               default:
                   send(client_socket, "Invalid password type. Use n, a, m, or s.\n", 41, 0);
                   continue;
           }

           printf("Generated password: %s\n", password);
           send(client_socket, password, strlen(password), 0); // Send password to client
       }

       closesocket(client_socket); // Disconnect client
       printf("Client connection closed.\n");
   }

   closesocket(server_socket); // Shutdown server
   clearwinsock(); // Cleanup
   return 0;
}
