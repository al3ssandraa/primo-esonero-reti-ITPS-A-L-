/*
 ============================================================================
 Name        : client_esonero.c
 Author      : Alessandra Loiodice (802371)
 Version     :
 Copyright   : Your copyright notice
 Description : client
 ============================================================================
 */


#include "protocol.h"

// Prints the error message to the standard error stream
void errorhandler(const char *error_message) {
   fprintf(stderr, "%s\n", error_message);
}

// Main client function to communicate with the server
int main(void) {
   setbuf(stdout, NULL); // Disable output buffering for real-time console output

   // Initialize Winsock (only for Windows systems)
   #if defined WIN32
   WSADATA wsa_data;
   int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
   if (result != 0) {
       fprintf(stderr, "Error at WSAStartup\n");
       return -1;
   }
   #endif

   // Create a TCP socket for the client
   int c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
   if (c_socket < 0) {
       errorhandler("Socket creation failed."); // Handle socket creation error
       #if defined WIN32
       clearwinsock(); // Clean up Winsock resources
       #endif
       return -1;
   }

   // Configure server address information
   struct sockaddr_in sad;
   memset(&sad, 0, sizeof(sad)); // Zero out the memory for the sockaddr structure
   sad.sin_family = AF_INET;    // Use IPv4
   sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // Specify server's loopback IP address
   sad.sin_port = htons(PROTOPORT);             // Convert server's port number to network byte order

   // Attempt to connect the client to the server
   if (connect(c_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
       errorhandler("Failed to connect to server."); // Handle connection error
       closesocket(c_socket); // Close the socket before exiting
       #if defined WIN32
       clearwinsock(); // Clean up Winsock resources
       #endif
       return -1;
   }

   printf("Connected to server.\n"); // Confirm connection to the server

   char request[BUFFERSIZE]; // Buffer to hold the client's request
   char response[BUFFERSIZE]; // Buffer to hold the server's response
   int password_length; // Length of the password requested by the user

   // Main loop to handle user input, send requests, and process responses
   while (1) {
       printf("Enter request (n/a/m/s <length>), or 'q' to quit: ");
       fgets(request, BUFFERSIZE, stdin); // Read user input from the console

       // Remove any trailing newline character from the input
       request[strcspn(request, "\n")] = 0;

       // Check if the user wants to quit the program
       if (strcmp(request, "q") == 0) {
           printf("Exiting program... Closing connection.\n");
           break;
       }

       // Validate the format of the user's input
       if (strlen(request) < 3) {
           printf("Invalid input. Format: <type> <length>\n"); // Input must be at least 3 characters
           continue;
       }

       // Extract the password length from the input
       if (sscanf(request + 2, "%d", &password_length) != 1 ||
           password_length < MIN_PASSWORD_LENGTH ||
           password_length > MAX_PASSWORD_LENGTH) {
           printf("Invalid length. Must be between %d and %d.\n", // Password length is out of range
                  MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
           continue;
       }

       // Send the formatted request to the server
       if (send(c_socket, request, strlen(request), 0) < 0) {
           errorhandler("Failed to send data to server."); // Handle sending error
           break;
       }

       // Receive the server's response (the generated password)
       int bytes_rcvd = recv(c_socket, response, BUFFERSIZE - 1, 0);
       if (bytes_rcvd <= 0) { // Check for errors or disconnection
           errorhandler("Failed to receive data from server."); // Handle receiving error
           break;
       }

       response[bytes_rcvd] = '\0'; // Add a null terminator to the received string
       printf("Generated password: %s\n", response); // Display the password to the user
   }

   // Close the client socket and clean up resources
   closesocket(c_socket);
   #if defined WIN32
   clearwinsock(); // Clean up Winsock resources for Windows
   #endif

   return 0; // Exit the program
}
