/*
 * protocol.h
 *
 *  Created on: 22 nov 2024
 *      Author: Alessandra Loiodice (802371)
 */


#ifndef PROTOCOL_H_
#define PROTOCOL_H_
#include <stdio.h>    // Standard I/O library for input and output functions
#include <stdlib.h>   // Standard library functions such as memory allocation and random number generation
#include <string.h>   // Functions for string manipulation and memory management
#include <time.h>     // Time-related functions, used for generating random numbers based on time

#if defined WIN32
#include <winsock2.h>   // Windows socket API for network communication
#include <ws2tcpip.h>   // Windows-specific functions for handling TCP/IP protocols
#define closesocket(s) closesocket(s)  // Redefine the closesocket function for Windows systems, which is different from UNIX
#else
#include <sys/socket.h>  // UNIX socket library for network communication
#include <arpa/inet.h>   // Functions for manipulating internet addresses and port numbers
#include <unistd.h>      // UNIX-specific functions for handling system resources
#define closesocket(s) close(s)       // Redefine closesocket for UNIX systems
#define clearwinsock()  // Empty function for UNIX, as cleanup is not needed on these systems
#endif

// Define the port number to be used for communication between the server and client
#define PROTOPORT 27015            // The default communication port for the server

// Define the maximum size for the data buffer used during communication
#define BUFFERSIZE 1024            // The size of the buffer for sending and receiving data between server and client

// Set the minimum and maximum allowed lengths for the generated passwords
#define MIN_PASSWORD_LENGTH 6      // The shortest password that can be requested
#define MAX_PASSWORD_LENGTH 32     // The longest password that can be requested

// Function prototypes for the password generation functions that will be implemented in the corresponding source file
void generate_numeric(char *password, int length); // Function to generate a numeric password
void generate_alpha(char *password, int length);   // Function to generate an alphabetic password
void generate_mixed(char *password, int length);   // Function to generate a mixed password (numeric and alphabetic)
void generate_secure(char *password, int length);  // Function to generate a secure password with special characters

#if defined WIN32

// Cleanup function for Winsock library used on Windows systems
void clearwinsock() {
   WSACleanup();  // Close and clean up the Winsock API to free resources on Windows
}
#endif // WIN32

#endif /* PROTOCOL_H_ */
